# Chinese Egret Detection > 2025-05-14 1:05pm
https://universe.roboflow.com/bird-census-management-test/chinese-egret-detection

Provided by a Roboflow user
License: CC BY 4.0

